# FitPlan – Fitness Routine Planner (PS 55)

A simple GenAI mini project that creates a weekly home-workout routine based on a user's goal, fitness level, available time, and equipment.

## Features
- Fitness goal selection
- Beginner, intermediate, or advanced level
- Workout duration from 10 to 60 minutes
- Equipment selection
- AI-generated 7-day plan with exercises, sets/reps, and rest days
- Simple Gradio interface

## Tech stack
- Python
- Gradio
- Google Gemini API (`gemini-2.5-flash`)

## Run in Google Colab

1. Upload this project folder or the ZIP to Colab and extract it.
2. Install dependencies:

   ```python
   !pip install -r requirements.txt
   ```

3. Set your Gemini API key (get one from Google AI Studio):

   ```python
   import os, getpass
   os.environ["GEMINI_API_KEY"] = getpass.getpass("Enter Gemini API key: ")
   ```

4. Launch the app:

   ```python
   !python app.py
   ```

A Gradio share link will appear. Open it to use FitPlan.

## Run locally

```bash
pip install -r requirements.txt
```

Set `GEMINI_API_KEY` as an environment variable, then run:

```bash
python app.py
```

## Project flow
User inputs → prompt construction → Gemini API → generated weekly workout plan → Gradio output.

## Safety
FitPlan provides general fitness information only. It does not diagnose conditions or replace advice from a qualified professional. Users should stop if they feel pain.

## Assignment
Roll No. 55 – Fitness Routine Planner
