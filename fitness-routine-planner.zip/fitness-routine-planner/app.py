import os
import gradio as gr
from google import genai

MODEL_NAME = "gemini-2.5-flash"


def generate_plan(goal, level, minutes, equipment):
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        return "**API key missing.** Set `GEMINI_API_KEY` in your environment before running the app."

    equipment_text = ", ".join(equipment) if equipment else "No equipment (bodyweight only)"

    prompt = f"""You are a cautious home-workout plan assistant for a student project.
Create a simple, beginner-safe 7-day home workout plan using the details below.

Goal: {goal}
Fitness level: {level}
Available time per workout: {minutes} minutes
Equipment available: {equipment_text}

Requirements:
- Include a table with columns: Day, Workout, Exercises, Sets x Reps/Time, Rest.
- Include 5 workout days maximum and at least 1 full rest day; make recovery sensible.
- Only use the equipment listed. If no equipment, use bodyweight exercises.
- Fit each session approximately within the available time.
- Use simple exercises and clear sets/reps or time. Give a brief warm-up and cool-down.
- Do not claim guaranteed results or diagnose medical conditions.
- Add a short safety note: stop if there is pain, use a comfortable range of motion,
  and consult a qualified professional if the user has a health concern.
- If the goal is weight loss, focus on sustainable activity and do not recommend
  extreme exercise, fasting, or rapid weight loss.
- Keep the answer concise and practical for a home workout.
"""

    try:
        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=prompt
        )
        result = (response.text or "").strip()
        if not result:
            return "The model returned an empty response. Please try again."
        return result
    except Exception as exc:
        return f"**Could not generate a plan.** Check your API key and internet connection.\n\nError: `{exc}`"


with gr.Blocks(title="FitPlan – Fitness Routine Planner") as demo:
    gr.Markdown("""
    # FitPlan 🏠
    ### Your simple weekly home-workout planner
    Choose your goal and available equipment to generate a practical 7-day routine.
    """)

    with gr.Row():
        with gr.Column():
            goal = gr.Dropdown(
                choices=["General fitness", "Weight loss", "Build strength", "Improve stamina", "Flexibility"],
                value="General fitness",
                label="Fitness goal"
            )
            level = gr.Radio(
                choices=["Beginner", "Intermediate", "Advanced"],
                value="Beginner",
                label="Fitness level"
            )
            minutes = gr.Slider(
                minimum=10, maximum=60, value=30, step=5,
                label="Minutes available per workout"
            )
            equipment = gr.CheckboxGroup(
                choices=["Yoga mat", "Dumbbells", "Resistance band", "Skipping rope", "Chair"],
                label="Equipment available (leave blank for bodyweight only)"
            )
            generate_btn = gr.Button("Generate weekly plan", variant="primary")
        with gr.Column():
            output = gr.Markdown("Your weekly plan will appear here.")

    generate_btn.click(
        fn=generate_plan,
        inputs=[goal, level, minutes, equipment],
        outputs=output
    )

    gr.Markdown(
        "**Safety note:** This app provides general fitness information, not medical advice. "
        "Choose movements appropriate for you and stop if you feel pain."
    )

if __name__ == "__main__":
    demo.queue().launch(share=True, show_error=True)
